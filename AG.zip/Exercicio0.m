function Exercicio0()
  pkg load io
##  CUMPRIDO: PESQUISAR SOBRE O FORMATO CÉLULA
##  CUMPRIDO: PESQUISAR SOBRE OS COMANDOS DE CSV
##  CUMPRIDO: IMPLEMENTAR O CONEITO DE TURMAS E ASSOCIAR AS DISCIPLINAS COM AS SUAS RESPECTIVAS TURMAS
##  CUMPRIDO: GERAR HORÁRIOS VÁLIDOS CONSIDERANDO TURMA, CADA MATÉRIA NA SUA TURMA
##  CUMPRIDO: ESCREVER O MELHOR RESULTADO NUM ARQUIVO, ORGANIZAR DE UMA FORMA FÁCIL DE ENTENDER
##  CUMPRIDO: REFORMULAR O MODELO PARA CONSEGUIR DAR NOTA AOS INDIVÍDUOS
##  CUMPRIDO: MÉTODO DE PUNTUAÇÃO, HORÁRIOS SEGUIDOS ALOCADOS TERÃO UMA NOTA MAIOR, 
##            SE FOREM DA MESMA MATÉRIA A NOTA SERÁ AINDA MAIOR, MULTIPLICADOR PARA MATÉRIAS SEGUIDAS
##  --> IMPLEMENTAR UMA TÉCNICA DE CRUZAMENTO 
##  --> IMPLEMENTAR UMA TÉCNICA DE MUTAÇÃO


##  Matriz lida de um arquivo
  listaDisciplinas = csv2cell('teste.csv');
  listaDisciplinas = listaDisciplinas(2:end, :);
  qtdeDisciplinas = size(listaDisciplinas, 1);
  qtdeIndividuos = 10;
  qtdeDias = 5;
  qtdeHorariosPorDia = 7;
  qtdeTurmas = size(unique(cell2mat(listaDisciplinas(:,4))),1);
  
  turmas = unique(cell2mat(listaDisciplinas(:,4)));
  nomeDisciplinas = listaDisciplinas(:,2);
  listaDisciplinas = cell2mat(listaDisciplinas(:,3:4));  
  gradeDisciplinas = zeros(size(listaDisciplinas,1),length(turmas));
  
  for i = 1:length(turmas)
      gradeDisciplinas(:,i) = listaDisciplinas(:,1) .* (listaDisciplinas(:,2) == turmas(i));
  endfor
 
  popBin = geraPopulacao(listaDisciplinas, qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos,gradeDisciplinas);
  cumpriRestricao = checaRestricoes(popBin,qtdeIndividuos,listaDisciplinas,gradeDisciplinas);
  

  [nota, grade]= nota(popBin);
  
  gravaResultado(nota,gradeDisciplinas,nomeDisciplinas,grade);
endfunction

function popBin = geraPopulacao(listaDisciplinas, qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos,gradeDisciplinas)
##  Gerar uma população inicial
##  gradeSemana controla a tabela de horários


  % Preencher a nova matriz com os dados das matérias separados por turma
  popBinSub = zeros(qtdeHorariosPorDia,qtdeDias,qtdeDisciplinas);
  popBin = zeros(qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos);
  % Vamos gerar horários aleátorios para cada par disciplina-indivíduo
  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      popBinSub = zeros(qtdeHorariosPorDia,qtdeDias,qtdeDisciplinas);
      for contDisciplina = 1:qtdeDisciplinas
        cargaHorariaDisciplina = listaDisciplinas(contDisciplina, 1);
        if gradeDisciplinas(contDisciplina,contTurma)~=0
          do
            popBinSub(:,:,contDisciplina) = popBin(:,:,contDisciplina,contTurma,contIndividuo);
            flagColisao = 0;
            diasDisciplina = randi([1 qtdeDias], 1, cargaHorariaDisciplina);
            horarioDisciplina = randi([1 qtdeHorariosPorDia], 1, cargaHorariaDisciplina);
            parDiaHorario = [diasDisciplina; horarioDisciplina];
            for contDiaHorario1 = 1:cargaHorariaDisciplina
              if popBinSub(horarioDisciplina(contDiaHorario1),diasDisciplina(contDiaHorario1),:)==0
                popBinSub(horarioDisciplina(contDiaHorario1),diasDisciplina(contDiaHorario1),contDisciplina) = 1;
              else
                flagColisao = 1;
                break
              endif
            endfor
          until flagColisao ~= 1
          popBin(:,:,contDisciplina,contTurma,contIndividuo) = popBinSub(:,:,contDisciplina);      
        endif
      endfor
    endfor
  endfor
  
endfunction

function passou =  checaRestricoes(popBin,qtdeIndividuos,listaDisciplinas,gradeDisciplinas)
  [qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos] = size(popBin);
  passou = zeros(qtdeTurmas,qtdeIndividuos);
  corrHorario = checaHorario(popBin);
  corrCarga = checaCarga(popBin,listaDisciplinas,gradeDisciplinas);
  corrHorario = sum(sum(corrHorario));
  corrCarga = sum(corrCarga);
  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      if corrHorario(1,1,contTurma,contIndividuo) == (qtdeHorariosPorDia*qtdeDias) && corrCarga(1,contTurma,contIndividuo) == qtdeDisciplinas
        passou(contTurma,contIndividuo) = 1;
      endif
    endfor
  endfor
endfunction

function correspondencia = checaCarga(popBin,listaDisciplinas,gradeDisciplinas)
  [qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos] = size(popBin);
  correspondencia = zeros(qtdeDisciplinas,qtdeTurmas,qtdeIndividuos);
  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      for contDisciplina = 1:qtdeDisciplinas
        valDisciplina = sum(sum(popBin(:,:,contDisciplina, contTurma, contIndividuo)));
##        cargaHorariaDisciplina = listaDisciplinas(contDisciplina, 1);
        if valDisciplina == gradeDisciplinas(contDisciplina,contTurma)
          correspondencia(contDisciplina, contTurma, contIndividuo) = 1;
        endif
      endfor
    endfor
  endfor
endfunction

function correspondencia = checaHorario(popBin)
  [qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos] = size(popBin);
  correspondencia = zeros(qtdeHorariosPorDia, qtdeDias,qtdeTurmas,qtdeIndividuos);
  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      for contDia= 1:qtdeDias
        for contHorario = 1:qtdeHorariosPorDia
          totalAulas = sum(popBin(contHorario,contDia,:,contTurma,contIndividuo));
          if totalAulas<=1
            correspondencia(contHorario, contDia, contTurma, contIndividuo) = 1;
          endif
        endfor
      endfor
    endfor
  endfor
endfunction

function [ranque, matriz] =nota(popBin)

  [qtdeHorariosPorDia, qtdeDias, qtdeDisciplinas, qtdeTurmas, qtdeIndividuos] = size(popBin);
  matriz = zeros(qtdeHorariosPorDia, qtdeDias, qtdeTurmas, qtdeIndividuos);
  matrizBin = zeros(qtdeHorariosPorDia, qtdeDias, qtdeTurmas, qtdeIndividuos);  
  soma = zeros(qtdeIndividuos,1);
  ranque = zeros(qtdeIndividuos,2);
  potJunto = 0;
  potDisc = 0;
  discAnt = 0;
  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      for contDisciplina = 1:qtdeDisciplinas
        for contDia = 1:qtdeDias
          for contHorario = 1:qtdeHorariosPorDia
            if popBin(contHorario,contDia,contDisciplina,contTurma,contIndividuo) ~=0
              matriz(contHorario,contDia,contTurma,contIndividuo) = contDisciplina;
              matrizBin(contHorario,contDia,contTurma,contIndividuo) += 1;
            endif
          endfor
        endfor
      endfor
    endfor
  endfor

  for contIndividuo = 1:qtdeIndividuos
    for contTurma = 1:qtdeTurmas
      for contDia = 1:qtdeDias
        for contHorario = 1:qtdeHorariosPorDia
          potJunto++;
          potDisc++;
          soma(contIndividuo) += matrizBin(contHorario,contDia,contTurma,contIndividuo)*potDisc*potJunto;
          if matrizBin(contHorario,contDia,contTurma,contIndividuo) == 0
            potJunto = 0;
          endif
          if matriz(contHorario,contDia,contTurma,contIndividuo) == discAnt && discAnt ~= 0
            potDisc *= 2;
          else
            potDisc = 0;
          endif
          discAnt = matriz(contHorario,contDia,contTurma,contIndividuo);
        endfor
        potJunto = 0;
        potDisc = 0;
      endfor
    endfor
  endfor
  [ranque(:,1),ranque(:,2)] = sort(soma,'descend');
  

end
function gravaResultado(nota,gradeDisciplinas,nomeDisciplinas,grade)
  melhor = grade(:,:,:,nota(1,2));
  [qtdeHorariosPorDia,qtdeDias,qtdeDisciplinas] = size(melhor);
  arquivo = cell(qtdeHorariosPorDia*qtdeDisciplinas+qtdeDisciplinas,qtdeDias);
  
  arquivo(1,:) = {"SEGUNDA",'TERÇA','QUARTA','QUINTA','SEXTA'};
  for contHorario = 1:qtdeHorariosPorDia
    for contDia = 1:qtdeDias
      for contDisciplina = 1:qtdeDisciplinas
        if melhor(contHorario,contDia,contDisciplina) ~= 0
          arquivo{contHorario+contDisciplina+((contDisciplina-1)*qtdeHorariosPorDia),contDia} =  nomeDisciplinas{melhor(contHorario,contDia,contDisciplina)};
        endif
      endfor


    endfor
  endfor
  cell2csv('resultado.csv', arquivo);
  
  keyboard 
  

  
endfunction